# FlowBuilder – Flowchart Practice App

A drag-and-drop flowchart builder for JSS2 and SS2 Computer Studies students.

## Features

- 4 flowchart symbols: Start/End, Process, Decision, Input/Output
- Drag symbols onto the canvas, connect them with arrows
- Double-click any shape to edit its label
- Separate exercises for JSS2 (4 tasks) and SS2 (4 tasks)
- **Check** button validates symbol counts and connectivity
- **Solution** panel shows the expected answer
- Delete mode removes shapes or individual arrows

## Local Development

```bash
npm install
npm run dev
```

## Deploy to Vercel

### Option A – Vercel CLI (fastest)
```bash
npm install -g vercel
npm run build
vercel --prod
```

### Option B – GitHub + Vercel Dashboard
1. Push this folder to a GitHub repository
2. Go to https://vercel.com → New Project → Import your repo
3. Vercel auto-detects Vite. Build command: `npm run build`, Output: `dist`
4. Click Deploy

## Exercises

### JSS2
1. Add Two Numbers
2. Even or Odd
3. Largest of Two Numbers
4. Grade a Score

### SS2
1. Count 1 to 10 (loop)
2. Factorial of N (loop)
3. Average of 5 Numbers (loop)
4. Find Largest in Array (nested loop/decision)
