import { useState, useRef, useCallback, useEffect } from 'react';

// ─── Symbol dimensions ───────────────────────────────────────────────────────
const DIM = {
  terminal: [150, 54],
  process:  [150, 54],
  decision: [150, 72],
  io:       [150, 54],
};
const W = t => DIM[t][0];
const H = t => DIM[t][1];

// ─── Symbol config ───────────────────────────────────────────────────────────
const SYM = {
  terminal: { label: 'Start / End',   fill: '#34d399', stroke: '#059669', text: '#064e3b' },
  process:  { label: 'Process',       fill: '#60a5fa', stroke: '#2563eb', text: '#1e3a8a' },
  decision: { label: 'Decision (If)', fill: '#fbbf24', stroke: '#d97706', text: '#78350f' },
  io:       { label: 'Input / Output',fill: '#e879f9', stroke: '#a21caf', text: '#4a044e' },
};

const SYM_ORDER = ['terminal', 'process', 'decision', 'io'];

const DEFAULT_TEXT = {
  terminal: 'Start',
  process:  'Process',
  decision: 'Condition?',
  io:       'Input/Output',
};

// ─── Unique ID ───────────────────────────────────────────────────────────────
let _counter = 0;
const uid = () => `n${++_counter}`;

// ─── Challenge data ──────────────────────────────────────────────────────────
const CHALLENGES = {
  jss2: [
    {
      title: 'Add Two Numbers',
      desc:  'Read two numbers A and B, calculate their sum, and display the result.',
      hint:  'Start → Input (A, B) → Process (Sum = A + B) → Output (Sum) → End',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input A, B' },
        { type: 'process',  text: 'Sum = A + B' },
        { type: 'io',       text: 'Display Sum' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 2, process: 1 },
    },
    {
      title: 'Even or Odd',
      desc:  'Read a number N and determine whether it is Even or Odd.',
      hint:  'Use a Decision diamond to check: N mod 2 = 0? Yes → Even, No → Odd',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input N' },
        { type: 'decision', text: 'N mod 2 = 0?' },
        { type: 'io',       text: 'Print "Even"' },
        { type: 'io',       text: 'Print "Odd"' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 3, decision: 1 },
    },
    {
      title: 'Largest of Two Numbers',
      desc:  'Read two numbers A and B, then display the larger one.',
      hint:  'Use a Decision diamond: A > B? Yes → Display A, No → Display B',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input A, B' },
        { type: 'decision', text: 'A > B?' },
        { type: 'io',       text: 'Display A' },
        { type: 'io',       text: 'Display B' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 3, decision: 1 },
    },
    {
      title: 'Grade a Score',
      desc:  'Read a student\'s score (0–100) and display the grade: A (70+), B (60–69), C (50–59), or F (below 50).',
      hint:  'Chain multiple Decision diamonds, one for each grade boundary.',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input Score' },
        { type: 'decision', text: 'Score ≥ 70?' },
        { type: 'decision', text: 'Score ≥ 60?' },
        { type: 'decision', text: 'Score ≥ 50?' },
        { type: 'io',       text: 'Grade = A' },
        { type: 'io',       text: 'Grade = B' },
        { type: 'io',       text: 'Grade = C' },
        { type: 'io',       text: 'Grade = F' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 5, decision: 3 },
    },
  ],
  ss2: [
    {
      title: 'Count 1 to 10',
      desc:  'Use a counting loop to display numbers from 1 to 10.',
      hint:  'Set N = 1, display N, increment N, then loop back until N > 10.',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'process',  text: 'N = 1' },
        { type: 'io',       text: 'Display N' },
        { type: 'process',  text: 'N = N + 1' },
        { type: 'decision', text: 'N > 10?' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, process: 2, io: 1, decision: 1 },
    },
    {
      title: 'Factorial of N',
      desc:  'Read a positive number N and calculate N! (factorial).',
      hint:  'Initialise F = 1, I = 1. Loop: F = F × I, I = I + 1. Stop when I > N.',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input N' },
        { type: 'process',  text: 'F = 1, I = 1' },
        { type: 'decision', text: 'I > N?' },
        { type: 'process',  text: 'F = F × I' },
        { type: 'process',  text: 'I = I + 1' },
        { type: 'io',       text: 'Display F' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 2, process: 3, decision: 1 },
    },
    {
      title: 'Average of 5 Numbers',
      desc:  'Use a loop to read 5 numbers one by one and calculate their average.',
      hint:  'Initialise Sum = 0, I = 1. Loop 5 times: read a number, add to Sum, increment I.',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'process',  text: 'Sum = 0, I = 1' },
        { type: 'io',       text: 'Input Num' },
        { type: 'process',  text: 'Sum = Sum + Num' },
        { type: 'process',  text: 'I = I + 1' },
        { type: 'decision', text: 'I > 5?' },
        { type: 'process',  text: 'Avg = Sum ÷ 5' },
        { type: 'io',       text: 'Display Avg' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 2, process: 4, decision: 1 },
    },
    {
      title: 'Find Largest in Array',
      desc:  'Read 5 numbers one by one and display the largest.',
      hint:  'Initialise Max with the first number. Compare each subsequent number with Max; update if larger.',
      steps: [
        { type: 'terminal', text: 'Start' },
        { type: 'io',       text: 'Input Max' },
        { type: 'process',  text: 'I = 2' },
        { type: 'io',       text: 'Input Num' },
        { type: 'decision', text: 'Num > Max?' },
        { type: 'process',  text: 'Max = Num' },
        { type: 'process',  text: 'I = I + 1' },
        { type: 'decision', text: 'I > 5?' },
        { type: 'io',       text: 'Display Max' },
        { type: 'terminal', text: 'End' },
      ],
      req: { terminal: 2, io: 3, process: 3, decision: 2 },
    },
  ],
};

// ─── SVG Shape Renderer ───────────────────────────────────────────────────────
function Shape({ type, text, w, h, selected }) {
  const s = SYM[type];
  const strokeW = selected ? 2.5 : 1.5;
  const strokeC = selected ? '#f97316' : s.stroke;
  const fs = text && text.length > 16 ? 9 : text && text.length > 12 ? 10 : 11;

  const lbl = (
    <text
      x={w / 2} y={h / 2}
      textAnchor="middle" dominantBaseline="middle"
      fontSize={fs} fontWeight="700" fill={s.text}
      fontFamily="Outfit, sans-serif"
      style={{ pointerEvents: 'none', userSelect: 'none' }}
    >
      {text}
    </text>
  );

  if (type === 'terminal') return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <rect x="2" y="2" width={w - 4} height={h - 4} rx={h / 2 - 2}
        fill={s.fill} stroke={strokeC} strokeWidth={strokeW} />
      {lbl}
    </svg>
  );

  if (type === 'process') return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <rect x="2" y="2" width={w - 4} height={h - 4}
        fill={s.fill} stroke={strokeC} strokeWidth={strokeW} />
      {lbl}
    </svg>
  );

  if (type === 'decision') {
    const mx = w / 2, my = h / 2;
    return (
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
        <polygon points={`${mx},2 ${w - 2},${my} ${mx},${h - 2} 2,${my}`}
          fill={s.fill} stroke={strokeC} strokeWidth={strokeW} />
        {lbl}
      </svg>
    );
  }

  if (type === 'io') {
    const sk = 16;
    return (
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
        <polygon points={`${sk},2 ${w - 2},2 ${w - 2 - sk},${h - 2} 2,${h - 2}`}
          fill={s.fill} stroke={strokeC} strokeWidth={strokeW} />
        {lbl}
      </svg>
    );
  }
}

// ─── Legend item (palette) ────────────────────────────────────────────────────
function PaletteItem({ type, onDragStart }) {
  const [hover, setHover] = useState(false);
  return (
    <div
      draggable
      onDragStart={e => onDragStart(e, type)}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      title={`Drag to add ${SYM[type].label}`}
      style={{
        marginBottom: 8, cursor: 'grab',
        opacity: hover ? 1 : 0.85,
        transform: hover ? 'scale(1.03)' : 'scale(1)',
        transition: 'all .15s',
      }}
    >
      <Shape type={type} text={SYM[type].label} w={W(type)} h={H(type)} />
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [level,    setLevel]    = useState('jss2');
  const [cIdx,     setCIdx]     = useState(0);
  const [nodes,    setNodes]    = useState([]);
  const [conns,    setConns]    = useState([]);
  const [mode,     setMode]     = useState('move');  // move | connect | delete
  const [selNode,  setSelNode]  = useState(null);
  const [cfrom,    setCfrom]    = useState(null);
  const [editing,  setEditing]  = useState(null);
  const [editTxt,  setEditTxt]  = useState('');
  const [feedback, setFeedback] = useState(null);    // { ok, msg }
  const [showSol,  setShowSol]  = useState(false);

  const canvasRef = useRef(null);
  const dragType  = useRef(null);
  const dragNode  = useRef(null);   // { id, ox, oy }
  const moved     = useRef(false);

  const ch = CHALLENGES[level][cIdx];

  // Clear on challenge/level change
  useEffect(() => {
    setNodes([]); setConns([]); setSelNode(null);
    setCfrom(null); setFeedback(null); setShowSol(false);
    setEditing(null); setMode('move');
  }, [level, cIdx]);

  // ── Palette drag ─────────────────────────────────────────────────────────
  const palDragStart = useCallback((e, type) => {
    dragType.current = type;
    e.dataTransfer.effectAllowed = 'copy';
  }, []);

  // ── Canvas drop ──────────────────────────────────────────────────────────
  const canvasDrop = useCallback(e => {
    e.preventDefault();
    const type = dragType.current;
    if (!type || !canvasRef.current) return;
    const r = canvasRef.current.getBoundingClientRect();
    const x = Math.max(10, e.clientX - r.left - W(type) / 2);
    const y = Math.max(10, e.clientY - r.top  - H(type) / 2);
    setNodes(ns => [...ns, { id: uid(), type, text: DEFAULT_TEXT[type], x, y }]);
    dragType.current = null;
  }, []);

  // ── Node drag (move) ─────────────────────────────────────────────────────
  const nodeMouseDown = useCallback((e, id) => {
    if (mode !== 'move') return;
    e.stopPropagation();
    moved.current = false;
    const nd = nodes.find(n => n.id === id);
    if (!nd || !canvasRef.current) return;
    const r = canvasRef.current.getBoundingClientRect();
    dragNode.current = { id, ox: e.clientX - r.left - nd.x, oy: e.clientY - r.top - nd.y };
    setSelNode(id);
  }, [mode, nodes]);

  const canvasMouseMove = useCallback(e => {
    if (!dragNode.current || !canvasRef.current) return;
    moved.current = true;
    const r = canvasRef.current.getBoundingClientRect();
    const x = Math.max(0, e.clientX - r.left - dragNode.current.ox);
    const y = Math.max(0, e.clientY - r.top  - dragNode.current.oy);
    setNodes(ns => ns.map(n => n.id === dragNode.current.id ? { ...n, x, y } : n));
  }, []);

  const canvasMouseUp = useCallback(() => { dragNode.current = null; }, []);

  // ── Node click ───────────────────────────────────────────────────────────
  const nodeClick = useCallback((e, id) => {
    e.stopPropagation();
    if (moved.current) { moved.current = false; return; }

    if (mode === 'delete') {
      setNodes(ns => ns.filter(n => n.id !== id));
      setConns(cs => cs.filter(c => c.from !== id && c.to !== id));
      if (selNode === id) setSelNode(null);
      return;
    }

    if (mode === 'connect') {
      if (!cfrom) {
        setCfrom(id);
      } else if (cfrom === id) {
        setCfrom(null);
      } else {
        if (!conns.some(c => c.from === cfrom && c.to === id)) {
          setConns(cs => [...cs, { from: cfrom, to: id }]);
        }
        setCfrom(null);
      }
      return;
    }

    setSelNode(p => p === id ? null : id);
  }, [mode, cfrom, conns, selNode]);

  // ── Double-click to edit label ────────────────────────────────────────────
  const nodeDblClick = useCallback((e, id) => {
    e.stopPropagation();
    if (mode !== 'move') return;
    const nd = nodes.find(n => n.id === id);
    if (!nd) return;
    setEditing(id);
    setEditTxt(nd.text);
  }, [mode, nodes]);

  const commitEdit = useCallback(() => {
    if (!editing) return;
    setNodes(ns => ns.map(n => n.id === editing ? { ...n, text: editTxt.trim() || n.text } : n));
    setEditing(null);
  }, [editing, editTxt]);

  // ── Canvas click (deselect) ───────────────────────────────────────────────
  const canvasClick = useCallback(() => {
    if (mode === 'connect') { setCfrom(null); return; }
    setSelNode(null);
  }, [mode]);

  // ── Delete connection on click ────────────────────────────────────────────
  const deleteConn = useCallback((from, to) => {
    setConns(cs => cs.filter(c => !(c.from === from && c.to === to)));
  }, []);

  // ── Check flowchart ───────────────────────────────────────────────────────
  const checkFlowchart = useCallback(() => {
    if (!nodes.length) {
      setFeedback({ ok: false, msg: 'Your canvas is empty — drag some shapes to get started!' });
      return;
    }

    const cnt = {};
    nodes.forEach(n => { cnt[n.type] = (cnt[n.type] || 0) + 1; });

    const issues = [];

    if ((cnt.terminal || 0) < 2)
      issues.push('You need at least 2 Terminal shapes — one for Start and one for End.');

    Object.entries(ch.req).forEach(([type, need]) => {
      const have = cnt[type] || 0;
      if (have < need)
        issues.push(`Need at least ${need} "${SYM[type].label}" shape${need > 1 ? 's' : ''} — you only have ${have}.`);
    });

    const linked = new Set();
    conns.forEach(c => { linked.add(c.from); linked.add(c.to); });
    const isolated = nodes.filter(n => !linked.has(n.id)).length;
    if (isolated > 0)
      issues.push(`${isolated} shape${isolated > 1 ? 's are' : ' is'} not connected to anything.`);

    if (issues.length === 0) {
      setFeedback({ ok: true, msg: '✓ Great work! Your symbol counts and connections look correct. Open the Solution panel to compare your logic.' });
    } else {
      setFeedback({ ok: false, msg: issues.join('  ·  ') });
    }
  }, [nodes, conns, ch]);

  // ── Connection bezier path ────────────────────────────────────────────────
  const getPath = useCallback((from, to) => {
    const a = nodes.find(n => n.id === from);
    const b = nodes.find(n => n.id === to);
    if (!a || !b) return null;
    const x1 = a.x + W(a.type) / 2, y1 = a.y + H(a.type);
    const x2 = b.x + W(b.type) / 2, y2 = b.y;
    const mid = (y1 + y2) / 2;
    return `M${x1},${y1} C${x1},${mid} ${x2},${mid} ${x2},${y2}`;
  }, [nodes]);

  // ── Midpoint of a bezier (for delete button) ──────────────────────────────
  const getMid = useCallback((from, to) => {
    const a = nodes.find(n => n.id === from);
    const b = nodes.find(n => n.id === to);
    if (!a || !b) return null;
    const x1 = a.x + W(a.type) / 2, y1 = a.y + H(a.type);
    const x2 = b.x + W(b.type) / 2, y2 = b.y;
    return { x: (x1 + x2) / 2, y: (y1 + y2) / 2 };
  }, [nodes]);

  const challenges = CHALLENGES[level];

  // ── Styles ────────────────────────────────────────────────────────────────
  const BG       = '#060d1a';
  const PANEL    = '#0c1628';
  const BORDER   = '#1e3a5f';
  const MUTED    = '#334d6e';
  const TEXT_DIM = '#475569';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: BG,
                  fontFamily: "'Outfit', sans-serif", color: '#e2e8f0', overflow: 'hidden' }}>

      {/* ── Header ── */}
      <header style={{ background: PANEL, borderBottom: `1px solid ${BORDER}`,
                       height: 54, display: 'flex', alignItems: 'center',
                       padding: '0 22px', gap: 14, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 17,
                      fontWeight: 800, color: '#38bdf8', letterSpacing: -0.3 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <rect x="1" y="6" width="22" height="12" rx="3" fill="#0ea5e9" opacity=".2" stroke="#38bdf8" strokeWidth="1.6"/>
            <circle cx="12" cy="12" r="2.5" fill="#38bdf8"/>
            <path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="#38bdf8" strokeWidth="1.6" strokeLinecap="round"/>
          </svg>
          FlowBuilder
        </div>

        <div style={{ width: 1, height: 24, background: BORDER, marginLeft: 4 }} />
        <span style={{ fontSize: 12, color: MUTED, fontWeight: 600 }}>Select level:</span>

        {['jss2', 'ss2'].map(l => (
          <button key={l} onClick={() => { setLevel(l); setCIdx(0); }}
            style={{ padding: '4px 20px', borderRadius: 20, border: `1.5px solid ${level === l ? '#38bdf8' : BORDER}`,
                     background: level === l ? '#0c4a6e' : 'transparent',
                     color: level === l ? '#38bdf8' : TEXT_DIM, fontWeight: 700, fontSize: 13,
                     cursor: 'pointer', transition: 'all .15s', fontFamily: 'inherit' }}>
            {l.toUpperCase()}
          </button>
        ))}

        <div style={{ marginLeft: 'auto', fontSize: 12, color: MUTED }}>
          Double-click a shape to edit its label
        </div>
      </header>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* ── Left sidebar ── */}
        <aside style={{ width: 196, background: PANEL, borderRight: `1px solid ${BORDER}`,
                        display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0 }}>

          {/* Symbol palette */}
          <div style={{ padding: '14px 14px 10px', borderBottom: `1px solid ${BORDER}` }}>
            <div style={{ fontSize: 10, fontWeight: 800, color: MUTED, textTransform: 'uppercase',
                          letterSpacing: 1.2, marginBottom: 10 }}>Symbols</div>
            <div style={{ fontSize: 10, color: '#1e3a5f', marginBottom: 10, fontWeight: 600 }}>
              ← Drag onto the canvas
            </div>
            {SYM_ORDER.map(type => (
              <PaletteItem key={type} type={type} onDragStart={palDragStart} />
            ))}
          </div>

          {/* Exercises list */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '12px 10px' }}>
            <div style={{ fontSize: 10, fontWeight: 800, color: MUTED, textTransform: 'uppercase',
                          letterSpacing: 1.2, marginBottom: 10, padding: '0 4px' }}>Exercises</div>
            {challenges.map((c, i) => (
              <button key={i} onClick={() => setCIdx(i)}
                style={{ display: 'block', width: '100%', textAlign: 'left', padding: '9px 12px',
                         borderRadius: 8, border: `1px solid ${cIdx === i ? '#1e6896' : '#1e293b'}`,
                         background: cIdx === i ? '#0c3554' : 'transparent',
                         color: cIdx === i ? '#7dd3fc' : '#64748b',
                         fontSize: 12, fontWeight: cIdx === i ? 700 : 500,
                         cursor: 'pointer', marginBottom: 5, transition: 'all .15s', fontFamily: 'inherit' }}>
                {c.title}
              </button>
            ))}
          </div>
        </aside>

        {/* ── Main area ── */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* Challenge info */}
          <div style={{ background: '#0a1628', padding: '10px 20px', borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
            <div style={{ fontWeight: 800, fontSize: 15, color: '#f1f5f9', marginBottom: 3 }}>{ch.title}</div>
            <div style={{ fontSize: 12, color: '#94a3b8', lineHeight: 1.55 }}>{ch.desc}</div>
            <div style={{ fontSize: 11, color: MUTED, marginTop: 3 }}>💡 {ch.hint}</div>
          </div>

          {/* Toolbar */}
          <div style={{ background: BG, padding: '7px 16px', display: 'flex', gap: 6,
                        alignItems: 'center', borderBottom: `1px solid #0f1f35`, flexShrink: 0 }}>

            {/* Mode buttons */}
            {[
              { m: 'move',    icon: '✋', label: 'Move'    },
              { m: 'connect', icon: '🔗', label: 'Connect' },
              { m: 'delete',  icon: '✕',  label: 'Delete'  },
            ].map(({ m, icon, label }) => (
              <button key={m} onClick={() => { setMode(m); setCfrom(null); }}
                style={{ padding: '4px 14px', borderRadius: 6, border: 'none', cursor: 'pointer',
                         fontSize: 12, fontWeight: 700, fontFamily: 'inherit', transition: 'all .15s',
                         background: mode === m
                           ? (m === 'delete' ? '#7f1d1d' : '#0369a1')
                           : (m === 'delete' ? '#1a0a0a' : '#1e293b'),
                         color: mode === m
                           ? (m === 'delete' ? '#fca5a5' : '#fff')
                           : (m === 'delete' ? '#ef4444' : '#64748b') }}>
                {icon} {label}
              </button>
            ))}

            <div style={{ width: 1, height: 22, background: BORDER, margin: '0 2px' }} />

            <button onClick={() => { setNodes([]); setConns([]); setFeedback(null); setSelNode(null); setCfrom(null); }}
              style={{ padding: '4px 14px', borderRadius: 6, border: 'none', cursor: 'pointer',
                       fontSize: 12, fontWeight: 700, fontFamily: 'inherit',
                       background: '#1e293b', color: '#64748b' }}>
              🧹 Clear
            </button>

            <button onClick={checkFlowchart}
              style={{ padding: '4px 16px', borderRadius: 6, border: 'none', cursor: 'pointer',
                       fontSize: 12, fontWeight: 700, fontFamily: 'inherit',
                       background: '#15803d', color: '#fff' }}>
              ✓ Check
            </button>

            <button onClick={() => setShowSol(v => !v)}
              style={{ padding: '4px 16px', borderRadius: 6, border: 'none', cursor: 'pointer',
                       fontSize: 12, fontWeight: 700, fontFamily: 'inherit',
                       background: showSol ? '#4c1d95' : '#3b1b6e', color: '#c4b5fd' }}>
              {showSol ? '🙈 Hide Solution' : '💡 Solution'}
            </button>

            {/* Context hint */}
            {mode === 'connect' && (
              <span style={{ fontSize: 11, color: '#fbbf24', fontWeight: 600, marginLeft: 8 }}>
                {cfrom ? '→ Click the destination shape' : '→ Click the source shape first'}
              </span>
            )}
            {mode === 'delete' && (
              <span style={{ fontSize: 11, color: '#f87171', fontWeight: 600, marginLeft: 8 }}>
                → Click a shape or arrow to delete it
              </span>
            )}
          </div>

          {/* Feedback bar */}
          {feedback && (
            <div style={{ padding: '8px 16px', flexShrink: 0, fontSize: 12, fontWeight: 600,
                          display: 'flex', alignItems: 'flex-start', gap: 10,
                          background: feedback.ok ? '#052e16' : '#450a0a',
                          color: feedback.ok ? '#4ade80' : '#f87171',
                          borderBottom: `1px solid ${feedback.ok ? '#16a34a' : '#dc2626'}` }}>
              <span style={{ flex: 1 }}>{feedback.msg}</span>
              <button onClick={() => setFeedback(null)}
                style={{ background: 'none', border: 'none', color: 'inherit', cursor: 'pointer',
                         fontSize: 16, lineHeight: 1, flexShrink: 0 }}>×</button>
            </div>
          )}

          {/* Canvas + Solution */}
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

            {/* Scrollable canvas wrapper */}
            <div style={{ flex: 1, overflow: 'auto' }}>
              <div
                ref={canvasRef}
                style={{
                  position: 'relative',
                  minWidth: 1400, minHeight: 800,
                  backgroundImage: 'radial-gradient(circle, #1a2d4a 1.2px, transparent 1.2px)',
                  backgroundSize: '28px 28px',
                  backgroundPosition: '14px 14px',
                }}
                onDrop={canvasDrop}
                onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }}
                onClick={canvasClick}
                onMouseMove={canvasMouseMove}
                onMouseUp={canvasMouseUp}
                onMouseLeave={canvasMouseUp}
              >
                {/* ── SVG layer for arrows ── */}
                <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%',
                              pointerEvents: 'none', zIndex: 1 }}>
                  <defs>
                    <marker id="arr" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
                      <polygon points="0 0,8 3,0 6" fill="#475569" />
                    </marker>
                    <marker id="arr-sel" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
                      <polygon points="0 0,8 3,0 6" fill="#f97316" />
                    </marker>
                  </defs>
                  {conns.map(c => {
                    const p = getPath(c.from, c.to);
                    if (!p) return null;
                    return (
                      <path key={`${c.from}-${c.to}`} d={p}
                        fill="none" stroke="#334d6e" strokeWidth="2"
                        markerEnd="url(#arr)" />
                    );
                  })}
                </svg>

                {/* ── Delete connection buttons (mode=delete) ── */}
                {mode === 'delete' && conns.map(c => {
                  const mid = getMid(c.from, c.to);
                  if (!mid) return null;
                  return (
                    <button key={`del-${c.from}-${c.to}`}
                      onClick={() => deleteConn(c.from, c.to)}
                      style={{ position: 'absolute', left: mid.x - 10, top: mid.y - 10,
                               width: 20, height: 20, borderRadius: '50%', border: 'none',
                               background: '#dc2626', color: '#fff', fontSize: 12, fontWeight: 800,
                               cursor: 'pointer', zIndex: 5, lineHeight: '20px', textAlign: 'center',
                               padding: 0 }}>
                      ×
                    </button>
                  );
                })}

                {/* ── Nodes ── */}
                {nodes.map(nd => (
                  <div key={nd.id} style={{
                    position: 'absolute', left: nd.x, top: nd.y,
                    width: W(nd.type), height: H(nd.type), zIndex: 2,
                    cursor: mode === 'delete' ? 'not-allowed' : mode === 'connect' ? 'crosshair' : 'grab',
                    filter: (selNode === nd.id || cfrom === nd.id)
                      ? `drop-shadow(0 0 7px ${cfrom === nd.id ? '#f97316' : '#0ea5e9'})`
                      : 'none',
                    transition: 'filter .1s',
                  }}
                    onMouseDown={e => nodeMouseDown(e, nd.id)}
                    onClick={e => nodeClick(e, nd.id)}
                    onDoubleClick={e => nodeDblClick(e, nd.id)}
                  >
                    <Shape type={nd.type} text={nd.text} w={W(nd.type)} h={H(nd.type)}
                      selected={selNode === nd.id || cfrom === nd.id} />

                    {/* Inline label editor */}
                    {editing === nd.id && (
                      <input
                        autoFocus
                        value={editTxt}
                        onChange={e => setEditTxt(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter' || e.key === 'Escape') commitEdit();
                        }}
                        onBlur={commitEdit}
                        placeholder="Type label…"
                        style={{
                          position: 'absolute', inset: 0, width: '100%', height: '100%',
                          background: 'rgba(2,8,23,.92)', color: '#e2e8f0',
                          border: '2px solid #38bdf8', borderRadius: 4,
                          textAlign: 'center', fontSize: 11, fontWeight: 700,
                          fontFamily: 'inherit', zIndex: 20,
                        }}
                      />
                    )}
                  </div>
                ))}

                {/* Empty state */}
                {nodes.length === 0 && (
                  <div style={{ position: 'absolute', inset: 0, display: 'flex',
                                alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
                    <div style={{ textAlign: 'center', color: '#1e3a5f' }}>
                      <div style={{ fontSize: 50, marginBottom: 14, opacity: 0.6 }}>📋</div>
                      <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 6 }}>Drag shapes from the left panel</div>
                      <div style={{ fontSize: 12 }}>Then switch to Connect mode to draw arrows between them</div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* ── Solution panel ── */}
            {showSol && (
              <div style={{ width: 192, background: PANEL, borderLeft: `1px solid ${BORDER}`,
                            overflow: 'auto', padding: '14px 14px', flexShrink: 0 }}>
                <div style={{ fontSize: 10, fontWeight: 800, color: MUTED, textTransform: 'uppercase',
                              letterSpacing: 1.2, marginBottom: 12 }}>Solution</div>
                {ch.steps.map((step, i) => (
                  <div key={i}>
                    <Shape type={step.type} text={step.text} w={W(step.type)} h={H(step.type)} />
                    {i < ch.steps.length - 1 && (
                      <div style={{ textAlign: 'center', fontSize: 18, color: MUTED, margin: '3px 0' }}>↓</div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
